# LCD Controllers

|                                      **Name**                                      | **Version** |
| ---------------------------------------------------------------------------------- | ----------- |
| EK9716B                                                                            | -           |
| [EK79007](https://components.espressif.com/components/espressif/esp_lcd_ek79007)   | 1.0.1       |
| [GC9A01](https://components.espressif.com/components/espressif/esp_lcd_gc9a01)     | 2.0.0       |
| [GC9B71](https://components.espressif.com/components/espressif/esp_lcd_gc9b71)     | 1.0.1       |
| [GC9503](https://components.espressif.com/components/espressif/esp_lcd_gc9503)     | 3.0.1       |
| [ILI9341](https://components.espressif.com/components/espressif/esp_lcd_ili9341)   | 2.0.0       |
| [ILI9881C](https://components.espressif.com/components/espressif/esp_lcd_ili9881c) | 1.0.0       |
| [JD9365](https://components.espressif.com/components/espressif/esp_lcd_jd9365)     | 1.0.1       |
| [NV3022B](https://components.espressif.com/components/espressif/esp_lcd_nv3022b)   | 0.0.1       |
| [SH8601](https://components.espressif.com/components/espressif/esp_lcd_sh8601)     | 1.0.0       |
| [SPD2010](https://components.espressif.com/components/espressif/esp_lcd_spd2010)   | 1.0.1       |
| ST7262                                                                             | -           |
| [ST7701](https://components.espressif.com/components/espressif/esp_lcd_st7701)     | 1.0.1       |
| ST7789                                                                             | -           |
| [ST7796](https://components.espressif.com/components/espressif/esp_lcd_st7796)     | 1.2.1       |
| [ST77916](https://components.espressif.com/components/espressif/esp_lcd_st77916)   | 0.0.2       |
| [ST77922](https://components.espressif.com/components/espressif/esp_lcd_st77922)   | 0.0.2       |
