# Core widgets

```eval_rst

.. toctree::
   :maxdepth: 1

   arc
   bar
   btn
   btnmatrix
   canvas
   checkbox
   dropdown
   img
   label
   line
   roller
   slider
   switch
   table
   textarea

```


